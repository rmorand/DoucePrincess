package domaine;

public class PlateauRect extends Plateau {
    private int longueur;
    private int largeur;

    public PlateauRect(String code, int nbPlaces, Matiere matiere, int longueur, int largeur) {
        super(code, nbPlaces, matiere);
        this.longueur = longueur;
        this.largeur = largeur;
    }

    @Override
    public int surface() { return longueur*largeur; }

    @Override
    public String toString() { return "Plateau rectangle " + super.toString() + " de " + longueur + "x" + largeur; }
}