package domaine;

public enum Matiere {
    BOIS, VERRE, PIERRE
}