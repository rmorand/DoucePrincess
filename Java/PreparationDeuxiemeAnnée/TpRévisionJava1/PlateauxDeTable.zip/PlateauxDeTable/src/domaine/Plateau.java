package domaine;

import java.util.Objects;

public abstract class Plateau implements Comparable<Plateau> {
    private String code;
    private int nbPlaces;
    private Matiere matiere;

    public Plateau(String code, int nbPlaces, Matiere matiere) {
        this.code = code;
        this.nbPlaces = nbPlaces;
        this.matiere = matiere;
    }

    public abstract int surface();

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Plateau plateau = (Plateau) o;
        return code.equals(plateau.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code);
    }

    @Override
    public int compareTo(Plateau p) {
        return this.code.compareToIgnoreCase(p.code);
    }

    public int compareSurface(Plateau p) {
        return this.surface() - p.surface();
    }

    public boolean estEn(Matiere matiere) { return this.matiere.equals(matiere); }

    @Override
    public String toString() {
        return "(" + code + ") : " + nbPlaces + " places, en " + matiere;
    }
}