package domaine;

public class PlateauRond extends Plateau {
    private int diametre;

    public PlateauRond(String code, int nbPlaces, Matiere matiere, int diametre) {
        super(code, nbPlaces, matiere);
        this.diametre = diametre;
    }

    @Override
    public int surface() { return (int) (Math.PI*(diametre/2)*(diametre/2)); }

    @Override
    public String toString() { return "Plateau rond " + super.toString() + " de diamètre " + diametre; }
}